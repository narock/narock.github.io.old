package sparql;

import com.hp.hpl.jena.query.ARQ;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.sparql.engine.http.QueryExceptionHTTP;

public abstract class Endpoints 
{
	// AGU Rackspace SPARQL Endpoint for abstracts
	public final String agu = "http://abstractsearch.agu.org:8890/sparql";
	
	protected ResultSet queryEndpoint ( String endpoint, String sparqlQueryString ) 
    {
    	Query query = QueryFactory.create(sparqlQueryString);
        ARQ.getContext().setTrue(ARQ.useSAX);
    	QueryExecution qexec = QueryExecutionFactory.sparqlService(endpoint, query);
    	ResultSet results = qexec.execSelect();                                       
    	qexec.close();
    	return results; 
    }
	
	public boolean testEndpoint ( String endpoint )
	{
		boolean isUp = false;
		String queryASK = "ASK { }";
    	Query query = QueryFactory.create(queryASK);
    	QueryExecution qe = QueryExecutionFactory.sparqlService(endpoint, query);
        try {
            if (qe.execAsk()) { isUp = true; } 
        }   catch (QueryExceptionHTTP e) { 
        	isUp = false;             
        } finally { qe.close(); } 
        return isUp;
	}
	
}