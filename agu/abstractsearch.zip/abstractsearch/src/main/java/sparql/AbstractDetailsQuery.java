package sparql;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.RDFNode;

import java.util.ArrayList;
import data.Agu;

public class AbstractDetailsQuery extends Endpoints {
	
	public ArrayList <String> getSessions ( String year, String section ) {
		
		ArrayList <String> results = new ArrayList <String> ();
		
		String query = 
		  "PREFIX p1: <http://abstractsearch.agu.org/ontology#> " + 
		  "PREFIX p2: <http://data.semanticweb.org/ns/swc/ontology#>  " +
		  "PREFIX p3: <http://swrc.ontoware.org/ontology#>  " +
		  "PREFIX p4: <http://tw.rpi.edu/schema/>  " +
		  "PREFIX p5: <http://xmlns.com/foaf/0.1/>  " +
		  "SELECT ?session   " +
		  "FROM <http://abstractsearch.agu.org/graphs/2.0/" + year + "/FM> " +
		  "WHERE { " +
		  "  ?session p1:section <http://abstractsearch.agu.org/sections/" + section + "> . " + 
		  "}";
		
		ResultSet queryResults = queryEndpoint( this.agu, query );
		while (queryResults.hasNext()) {
			 
  		   QuerySolution soln = queryResults.nextSolution();
  		   RDFNode session = soln.get("?session");
  		   results.add( session.toString().trim() );
  		   
		}
		
		return results;
		
	}
	
	private String createQueryString ( String year, String session ) {

		String sessionURI = "<" + session + ">";
		String uri = "<http://abstractsearch.agu.org/graphs/2.0/" + year + "/FM>";
		
		String query = 
			"PREFIX p1: <http://abstractsearch.agu.org/ontology#> " +
			"PREFIX p2: <http://data.semanticweb.org/ns/swc/ontology#> " + 
			"PREFIX p3: <http://swrc.ontoware.org/ontology#> " + 
			"PREFIX p4: <http://tw.rpi.edu/schema/> " + 
			"PREFIX p5: <http://xmlns.com/foaf/0.1/> " + 
			"SELECT ?abstract ?title ?text ?session ?author " +
			"FROM " + uri + " " +
			"WHERE { " + 
			  "?abstract a p1:Abstract . " +  
			  "?abstract p3:abstract ?text . " + 
			  "?abstract p2:relatedToEvent " + sessionURI + " . " + 
			  "?abstract p4:hasAgentWithRole ?author . " +
			  "?abstract <http://purl.org/dc/terms/title> ?title . " +

			"}";
		return query;
	
	}
					
	private Agu haveUri( String uri, ArrayList <Agu> abstracts ) {
	
		Agu a = null;
		for (int i=0; i<abstracts.size(); i++ ) {
		   a = abstracts.get(i);
		   if ( a.getIdentifier().equals(uri) ) { return a; }
		}
		return null;
		
	}
	
	private boolean replaceAbstract ( String uri, ArrayList <Agu> abstracts ) {
		
		for (int i=0; i<abstracts.size(); i++ ) {
		   Agu a = abstracts.get(i);
		   if ( a.getIdentifier().equals(uri) ) { 
			   abstracts.set(i, a); 
			   return true; 
		   }
		}
		return false;
	}
	
	public boolean testEndpoint () { boolean up = this.testEndpoint( this.agu ); return up; }
	
	public ArrayList <Agu> getAbstracts( String year, String session ) {
		 		 
		 ArrayList <Agu> abstracts = new ArrayList <Agu> ();
		 
		 AuthorExpansionQuery authorQuery = new AuthorExpansionQuery ();
		 
		 ResultSet results = queryEndpoint( this.agu, createQueryString( year, session ) );
		 while (results.hasNext()) {
			 
   		   QuerySolution soln = results.nextSolution();
   		   RDFNode abstractUri = soln.get("?abstract");
   		   RDFNode title = soln.get("?title");
   		   RDFNode text = soln.get("?text");
   		   RDFNode author = soln.get("?author");
   		
   		   // we are going to get the same uri multiple times 
		   // if we already have this uri then retrieve object and update
   		   Agu a = haveUri( abstractUri.toString(), abstracts );  
   		   if ( a == null ) { a = new Agu (); }
		   
		   // clean up the abstract text
		   String absText = text.toString();
		   absText = absText.replace("<", "&lt;");
		   absText = absText.replace(">", "&gt;");
		   
		   // clean up the title
		   String t = title.toString().trim();
		   String[] parts = t.split("@");
		   
		   // set the values to our object
		   a.setTitle( parts[0] );
		   a.setIdentifier( abstractUri.toString().trim() );
		   a.setAbstractText( absText );
		   //a.setSection(section);
		   a.setSession(session);
		   
		   // we have an author identifier
		   // convert to name and email
		   String[] name = authorQuery.submitQuery(author.toString().trim());
		   a.addAuthor( name );
		   
		   // add this abstract to our results list
		   boolean found = replaceAbstract ( abstractUri.toString().trim(), abstracts );
		   if ( !found ) { abstracts.add(a); }
		   
   	     } // end while
		 
		 return abstracts;
		 
	 }
	 	
}