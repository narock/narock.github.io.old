package sparql;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.RDFNode;

public class AuthorExpansionQuery extends Endpoints {
	
	private String createQueryString ( String authorUri ) {
			   
	   String query =
			"SELECT DISTINCT ?person ?name ?mbox where { " +
            "?person <http://tw.rpi.edu/schema/hasRole> <" + authorUri + "> . " +
            "?person <http://xmlns.com/foaf/0.1/name> ?name	. " +
            "?person <http://xmlns.com/foaf/0.1/mbox> ?mbox . " +
			"}";

	   return query;
	
	}
	
	public String[] submitQuery( String authorUri ) {
		 		
 		 String[] p = { null, null, null };
		 String personID, personName, personEmail;
		 ResultSet results = queryEndpoint( this.agu, createQueryString( authorUri ) );
		 while (results.hasNext()) {
			 
   		   QuerySolution soln = results.nextSolution();
   		   RDFNode person = soln.get("?person");
   		   RDFNode name = soln.get("?name");
   		   RDFNode mbox = soln.get("?mbox");
   		   
   		   // Person ID
   		   personID = person.toString();
   		   String[] parts = personID.split("@");
   		   personID = parts[0].trim();
   		   
   		   // Person Name
   		   personName = name.toString();
   		   parts = personName.split("\\^");
   		   personName = parts[0].trim();
   		   
   		   // Person Email
   		   personEmail = mbox.toString();
   		   parts = personEmail.split("\\^");
   		   personEmail = parts[0].trim();
   		   
   		   p[0] = personID;
   		   p[1] = personName; 
   		   p[2] = personEmail;
   		   
   	     } // end while
		 
 		 return p;
		 
	 }
	 	
}