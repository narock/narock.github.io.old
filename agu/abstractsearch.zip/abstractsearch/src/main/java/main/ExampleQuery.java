package main;

import sparql.AbstractDetailsQuery;
import java.util.ArrayList;
import data.Agu;

public class ExampleQuery {

	public static void main( String[] args ) {
		
		// Create the query object
		AbstractDetailsQuery query = new AbstractDetailsQuery();

		// Is the public endpoint available?
		boolean available = query.testEndpoint();
		if ( available ) {
			
			System.out.println("AGU Abstract Database Available...");
			
			// There's too much data to query all at once. Loop over the data by year and section
			String year = "2015";
			String[] sections = {"A", "AE", "B", "C", "DI", "ED", "EP", "G", "GC", "GP", "H", "IN","MR",
		                "NG","NH", "NS","OS", "P", "PA", "PP", "S", "SA", "SH","SM","T","U","V"};
			
			for ( int i=0; i<sections.length; i++ ) {

				// Get all the sessions for this year/sections
				ArrayList <String> sessions = query.getSessions(year, sections[i]);
				System.out.println("Found " + sessions.size() + " sessions for " + year + "/" + sections[i]);
				
				// Get the abstracts for each session
				for ( int j=0; j<sessions.size(); j++ ) {
				
					ArrayList <Agu> abstracts = query.getAbstracts(year, sessions.get(j));
					System.out.println("Found " + abstracts.size() + " abstracts in: " + sessions.get(j));
					
					// Print out the results
					for ( int k=0; k<abstracts.size(); k++ ) {
					  Agu a = abstracts.get(k);
					  System.out.println("Abstract ID: " + a.getIdentifier());
					  System.out.println("Title: " + a.getTitle());
					  System.out.println("Abstract Text: " + a.getAbstractText());
					  System.out.println("Presented in Section: " + sections[i]);
					  System.out.println("Presented in Session: " + a.getSession());
					  System.out.println("Authors: ");
					  ArrayList <String[]> authors = a.getAuthors();
					  for ( int l=0; l<authors.size(); l++ ) { 
						String[] author = authors.get(l);
						System.out.println("    " + author[0] + " " + author[1] + " " + author[2]);
					  }
					System.out.println();
					}
					
				} // end loop over all sessions
				
			} // end loop over all sections

		} else { System.out.println("AGU Abstract Database Not Available"); }
		
		
	}
	
}