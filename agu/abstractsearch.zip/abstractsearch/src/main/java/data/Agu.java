package data;

import java.util.ArrayList;

public class Agu {
		
	private String identifier;
	private String title;
	private String text;
	private String session;
	private String section;
	
	private ArrayList <String[]> authors = new ArrayList <String[]> ();
	
	public String getIdentifier() { return this.identifier; }
	public void setIdentifier( String s ) { this.identifier = s; }

	public ArrayList <String[]> getAuthors () { return authors; }
	
	public void addAuthor ( String[] s ) { 
		boolean found = false;
		for (int i=0; i<authors.size(); i++) {
			String[] a = authors.get(i);
			if ( a[0].equals(s[0]) ) { found = true; break; }
		}
		if ( !found ) { authors.add(s); }
	}
	
	public String getTitle () { return title; }
	public String getAbstractText () { return text; }
	public String getSession () { return session; }
	public String getSection () { return section; }
	
	public void setTitle ( String t ) { title = t; }
	public void setAbstractText ( String t ) { this.text = t; }
	public void setSession ( String s ) { this.session = s; }
	public void setSection ( String s ) { this.section = s; }
		
}